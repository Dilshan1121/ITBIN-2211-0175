/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

/**
 *
 * @author Dilshan
 */
import View.Login;
import View.Form;
import View.Home;
import View.score;
import View.Display;
import View.Show;
import View.Delete;
import View.DScore;
// Correct import statement

public class HomeController {
    
    public static void navigateToLogin() {
        new Login().setVisible(true);
    }
    
    public static void navigateToForm() {
        new Form().setVisible(true);
    }
    
    public static void navigateToHome() {
        new Home().setVisible(true);  // Correct class name
    }
    
    public static void navigateToscore() {
        new score().setVisible(true);
    }
    
   
   
    public static void navigateToDisplay() {
        new Display ().setVisible(true);}
        
    public static void navigateToShow() {
        new Show ().setVisible(true);
}
 
 public static void navigateToDScore() {
        new DScore().setVisible(true);
    }
  public static void navigateToDelete() {
       new Delete(new DeletePlayerController()).setVisible(true);
    }
}