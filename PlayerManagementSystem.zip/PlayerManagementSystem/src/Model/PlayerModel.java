/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Dilshan
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class PlayerModel {
      private Connection connect() {
        String url = "jdbc:mysql://localhost:3306/playermanagement";
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(url, "root", ""); // Adjust credentials
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return conn;
    }

    public boolean deletePlayer(String playerID) {
        String deletePlayerSQL = "DELETE FROM player WHERE playerID = ?";
        String deleteScoreSQL = "DELETE FROM score WHERE playerID = ?";

        try (Connection conn = this.connect();
             PreparedStatement pstmtPlayer = conn.prepareStatement(deletePlayerSQL);
             PreparedStatement pstmtScore = conn.prepareStatement(deleteScoreSQL)) {

            conn.setAutoCommit(false); // Start transaction

            // Delete from score table
            pstmtScore.setString(1, playerID);
            pstmtScore.executeUpdate();

            // Delete from player table
            pstmtPlayer.setString(1, playerID);
            int affectedRows = pstmtPlayer.executeUpdate();

            conn.commit(); // Commit transaction

            return affectedRows > 0;

        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return false;
        }
    }
}
    

