/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Dilshan
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DBConnection {

 private static Connection conn;
    private static Statement stat;

    // Establish the connection
    public static Statement getStatementConnection() {
        if (conn == null) {
            try {
                String url = "jdbc:mysql://localhost:3306/playermanagement"; // Replace with your database name
                conn = DriverManager.getConnection(url, "root", ""); // Replace with your database username and password
                stat = conn.createStatement();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return stat;
    }

    // Close the connection
    private static Connection con;

    public static Connection getConnection() {
        if (con == null) {
            try {
                con = DriverManager.getConnection("jdbc:mysql://localhost:3306/playerManagement", "root", "");
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return con;
    }

    public static void closeCon() {
        if (con != null) {
            try {
                con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}

    

