/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Dilshan
 */
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.Connection;

public class AddRecord {
    
    public void addPlayer(String firstName, String lastName, String playerId, String age, String gender, String contactNumber, String email, String category) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        
        try {
            conn = DBConnection.getConnection();
            String sql = "INSERT INTO player (firstName, lastName, playerId, age, gender, contactNumber, email, category) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, firstName);
            pstmt.setString(2, lastName);
            pstmt.setString(3, playerId);
            pstmt.setString(4, age);
            pstmt.setString(5, gender);
            pstmt.setString(6, contactNumber);
            pstmt.setString(7, email);
            pstmt.setString(8, category);
            pstmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (pstmt != null) pstmt.close();
                if (conn != null) DBConnection.closeCon();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    
}