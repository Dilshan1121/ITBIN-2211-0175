/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

/**
 *
 * @author Dilshan
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import Model.DBSearch;
import View.Display;
import java.sql.ResultSet;
import java.util.Vector;
import javax.swing.table.DefaultTableModel;
import Model.PlayerModel;


public class playerController {
     private PlayerModel playerModel;
    private DBSearch dbSearch;
    private Display view;

    public playerController() {
        this.playerModel = new PlayerModel();
        this.dbSearch = new DBSearch();
    }

    public playerController(Display view) {
        this.view = view;
        this.dbSearch = new DBSearch();
    }
    
   public static void Form(String firstName, String lastName, String playerId, String age, String gender, String contactNumber, String email, String category) throws SQLException {
       String url = "jdbc:mysql://localhost:3306/playerManagement";
       String user = "root"; // Replace with your database username
       String password = ""; // Replace with your database password

       Connection conn = null;
       PreparedStatement pstmt = null;

       try {
           conn = DriverManager.getConnection(url, user, password);
           String sql = "INSERT INTO player (firstName, lastName, playerId, age, gender, contactNumber, email, category) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
           pstmt = conn.prepareStatement(sql);
           pstmt.setString(1, firstName);
           pstmt.setString(2, lastName);
           pstmt.setString(3, playerId);
           pstmt.setString(4, age);
           pstmt.setString(5, gender);
           pstmt.setString(6, contactNumber);
           pstmt.setString(7, email);
           pstmt.setString(8, category);
           pstmt.executeUpdate();
       } finally {
           if (pstmt != null) {
               pstmt.close();
           }
           if (conn != null) {
               conn.close();
           }
       }
   }
   
  

      public void deletePlayer(String playerID) {
        if (playerID != null && !playerID.isEmpty()) {
            boolean isDeleted = playerModel.deletePlayer(playerID);
            if (isDeleted) {
                System.out.println("Player deleted successfully.");
            } else {
                System.out.println("Failed to delete player.");
            }
        } else {
            System.out.println("Player ID cannot be empty.");
        }
    }
    
    

    /**
     *
     * @param view
     */
    
    public void displayAllPlayers() {
        ResultSet rs = dbSearch.getAllPlayers();
        DefaultTableModel model = view.getTableModel();
        model.setRowCount(0); // Clear existing table data

        try {
            while (rs.next()) {
                Object[] row = {
                    rs.getString("firstName"),
                    rs.getString("lastName"),
                    rs.getString("playerID"),
                    rs.getInt("age"),
                    rs.getString("gender"),
                    rs.getString("contactNumber"),
                    rs.getString("email"),
                    rs.getString("category")
                };
                model.addRow(row);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
  
    public void displayAllScore() {
        ResultSet rs = dbSearch.getAllScore();
        DefaultTableModel model = view.getTableModel();
        model.setRowCount(0); // Clear existing table data

        try {
            while (rs.next()) {
                Object[] row = {
                    rs.getString("playerID"),
                    rs.getString("score"),
                   
                };
                model.addRow(row);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

