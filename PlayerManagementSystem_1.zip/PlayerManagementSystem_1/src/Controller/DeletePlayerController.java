/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

/**
 *
 * @author Dilshan
 */
import Model.PlayerModel;

public class DeletePlayerController {


    private PlayerModel playerModel;

    public DeletePlayerController() {
        this.playerModel = new PlayerModel();
    }

    public boolean deletePlayer(String playerID) {
        if (playerID != null && !playerID.isEmpty()) {
            boolean isDeleted = playerModel.deletePlayer(playerID);
            if (isDeleted) {
                System.out.println("Player deleted successfully.");
            } else {
                System.out.println("Failed to delete player.");
            }
            return isDeleted;
        } else {
            System.out.println("Player ID cannot be empty.");
            return false;
        }
    }

    public void setVisible(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}

    

