/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

/**
 *
 * @author Dilshan
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import Model.PlayerModel;
import javax.swing.JOptionPane;
import Model.DBSearch;
import View.DScore;
import java.sql.ResultSet;
import java.util.Vector;
import javax.swing.table.DefaultTableModel;
import Model.PlayerModel;

public class scoreController {
    
    private PlayerModel playerModel;
    private DBSearch dbSearch;
    private DScore view;

    public scoreController() {
        this.playerModel = new PlayerModel();
        this.dbSearch = new DBSearch();
    }

    public scoreController(DScore view) {
        this.view = view;
        this.dbSearch = new DBSearch();
    }
    
 public static void score(String playerID, String score) {
        String url = "jdbc:mysql://localhost:3306/playerManagement";
        String user = "root";
        String password = "";

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = DriverManager.getConnection(url, user, password);
            String sql = "INSERT INTO score (playerID, score) VALUES (?, ?)";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, playerID);
            pstmt.setString(2, score);

            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
 
 public void displayAllScore() {
        ResultSet rs = dbSearch.getAllScore();
        DefaultTableModel model = view.getTableModel();
        model.setRowCount(0); // Clear existing table data

        try {
            while (rs.next()) {
                Object[] row = {
                    rs.getString("playerID"),
                    rs.getString("score"),
                   
                };
                model.addRow(row);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
