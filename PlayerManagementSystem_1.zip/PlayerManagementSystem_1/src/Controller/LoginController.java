/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

/**
 *
 * @author Dilshan
 */



import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import Model.DBConnection;
import Model.DBSearch;
import View.Home;

public class LoginController {
   public static boolean login(String userName, String password) {
        ResultSet rs = null;
        try {
            String dbUsername = null;
            String dbPassword = null;
            rs = new DBSearch().searchLogin(userName);

            // Process the Query
            while (rs.next()) {
                dbUsername = rs.getString("UserName"); // Assuming column name in database is UserName
                dbPassword = rs.getString("Password"); // Assuming column name in database is Password
            }

            if (dbUsername != null && dbPassword != null) {
                if (dbPassword.equals(password)) {
                    System.out.println("Login Successful");
                    new Home().setVisible(true); // Open the home window
                    return true; // Indicate successful login
                } else {
                    JOptionPane.showMessageDialog(null, "Incorrect Password", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(null, "Username not found", "Error", JOptionPane.ERROR_MESSAGE);
            }

        } catch (SQLException ex) {
            Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, "Database error during login", ex);
        } finally {
            try {
                if (rs != null) rs.close(); // Close ResultSet
                DBConnection.closeCon(); // Close database connection
            } catch (SQLException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, "Error closing resources", ex);
            }
        }
        return false; // Indicate failed login
    }
}

